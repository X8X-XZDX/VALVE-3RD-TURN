Uncle Dane -- Server Host + Content Creator
SquimJim -- Creator + Organizer


Needed:  Community spokesmen
