Author: X8X_XZDX

# For All New Contributors

This is a simple help file to get started.

To get started with this Github Repo, first, login.  You can use a Google account, Microsoft Account, or, create an Account.

Below you will find a simple list of tools to help you get started.  The only requirement, AT MINIMUM, is that you get a Github client on your desktop.  Or use git, it doesn't matter, but a recommended tool, GitButler, is listed below.  This will be the most flexible tool for the job.

### The total Download size of this repo, for now, is less than 2mb.

# Recommended Tools for Working On V3T Github

Just a short list of tools for people to use on the github.  This is by no means a requirement, but definitely recommended for sake of simplicity, ease of use, a full streamlined process that you only need learn how to use with a few google searches or BingGPT questions, and you're off to the races like the rest of us.

These are either Free ($$$) tools, or Free (FOSS) tools.  At the end of the day, if you don't care, you'll not need to pay for this software at any point.  However, if you can, it would be appreciated by the developers.

---------------------------------------------------------

LibreOffice:  https://www.libreoffice.org/

Free, arguably better, MS Office, that can run on most anything.

--------------------------------------------

TreeSheets:  https://strlen.com/treesheets/

Free mindmap / complexDoc tool.

-------------------------------------------

Github Desktop:  https://github.com/apps/desktop

The Github desktop app.  There are others, such at gitbutler, but upon further inspection, I want to recommend the default to any new users.

--------------------------------------------------

Notepad++:  https://notepad-plus-plus.org/

A clean and multi-language compatible notepad tool.  As the Github documentation is all done in Markdown, unless you have an ODF to upload, or a CSV, please use this tool, and please keep everything to a Markdown File.  Adjustments can be made later, if need be.

----------------------------------------------------

Gihub Documentation:  https://docs.github.com/en

If you have any questions about Github, Markdown, Formatting, Everything, it should be findable in here, to some extent.  If not, try GPT, and not the bing one, the closed one on the OpenAI website.

-------------------------------------------------------


Any further tools will be added as needed.




