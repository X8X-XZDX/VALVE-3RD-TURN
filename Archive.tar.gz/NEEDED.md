Contributors Needed, In Context:

TF2
  Mappers
  Weapon Designers
  Content Creators - Balancers - Commentators
  Server Owners / Moderators
  Server Mod Creators
  Competitive Input

  
Steam
  Client Users
  Client Modders
  Skin Designers
  UI/UX Suggestions
  Social Media Designs
  
Someone else besides XZDX who gives a fuck about their favorite games, and community.





Github

  Contributors
