# Stats for Github Joins / Rejects

| Accepted invite to | Github | Discord |
|--------------------|--------|---------|
| Twitch | 1 | . |
| Steam | 2 | 2 |


| Banned for Introducing | Github |
|------------------------|--------|
| Discord Bans | 6 |
| Steam Community | 2 |
| Steam Mutes | 3 |
| Twitch Chat | 4 |
| Twitch Rejection | 5 |

**Rejection meaning said no.  Could follow ban.


| Servers open to hearing about | #V3T | Github + Steam Deck Concept |
|-------------------------------|------|-----------------------------|
| Casual | 1 | 1 |
| Comp | . | . |
| Community | . | 1 |

| Chat Clouseouts | Steam | Discord | Twitch | In-Game | Banned fr Socials |
|-----------------|-------|---------|--------|---------|-------------------|
| Brie | X | . | . | . | . |
| UDane | . | X | X | . | X |
| SquimJim | . | X | . | x | . |





Notated by XZDX
