
Heres the problem in totality as it stands. Top to bottom, including the community issues.

Over the years, Valve has grown interested in other things, and at this point, one person is the TF2 staff. They are doing a 64bit port, they are working on these botlists and "treadmill work" as it were, they are OK-ing hats and skins for boxes, arranging the boxes, and hoping he hits enough of a profit quota to leave data dense systems like MM running.

Valve in the meantime has gone on and pumped up Source 2 but only released 3 games with it in 6 years, 2 of them on VR, one with an assblasted bot problem at launch. Not to mention the recent Apex Legends hack DURING A TOURNAMENT. They've released new games! That no one cared about. But one was Half Life! That no one could play because of hardware restrictions.

Ah but the steam deck, the one actual beacon of hope. Consistant hardware sales, hell everyone loved the DS, so lets make an AyaNeo X2 but make it actually work! And they managed to make a GOOD PORTABLE. You can do some desktop things, you can do some gaming, and then you realise you have gen 3 of the playstation portable series because it doesn't have the oomph it needs.

On top of it, new hires and contractors come in, get told they aren't "Real Valve", and are harrassed until they leave because the money hungry apes in the C Suite don't want new ideas, they want Newgrounds with AAA Games instead of those stupid flash games.

Similarly, the community wants the trading bots gone, but don't want to stop their own rape and seizure on the items market. They want the hacker bots gone, but they also want to insist that theres a competitive meta and you're playing the game wrong and will berrate you AND FOLLOW YOU ACROSS SERVERS to harrass you because they have to be correct.

Other people on youtube Roleplay that they are Valve employees because they got a neat tour for making cool videos on youtube. Maybe they even get an email once in a while 9.9 oooooooooo and then they LEAK THE ♥♥♥♥♥♥♥ DATA ON STREAM LIKE A MORON.

None of these people are invited to Valve because they are untrustworthy, and do not commit to ideas solidly, they commit to profittable ideas. Valve, at least used to, try to commit to good profits, as well as good efforts for the user.

This has long since languished. The only good part left is the 30/70 STANDARD CUT for developers, as prices of non-indie games skyrocket to meet corporate profit margins.

All of this, ironically, starting with stupid loot boxes with funny hats.

What I argue should be done is everyone compile their ideas in a github (Valve 3rd Turn), and with the signatures that they got, submit ideas. If they submit empty signatures, the names mean literally nothing to Valve, who of the most of 300 people, do not give a ♥♥♥♥ about this game, whatsoever.

It is unrealistic to expect one employee to upkeep this game.

Valve needs to throw out the workshop, implement a git system instead, and start working towards releasing games like TF2, CSS, CSGO, in limited format, to the communities, as a modding hub. This would not be unlike years past where modding groups MADE TF, OR CS, and would, instead of killing mods (and their community) like CSCO out of fear of competition, encourage 5000 other mods that would not even begin to allow competition with the main product. As well, as a result, were Valve to get tired of an idea, they could look at the communities work. Should valve need a hire, they see who is committing what. You want to work at valve? Make a lot of contributions, hope you're in the right spot. Then they don't have any potential for leaks thru job ads like in years past.

Sadky though every TF2 community member is literally too childish and money hungry to even begin to think outside of the box, and are putting their jobs at risk because of it.

Were valve to get hit with any of the monopoly lawsuits, that, at least one is kind of correct IMO, would do significant damage to valve. And in order to save things like the steam deck, the first things to go are Source 1 game servers.

But even with that, new game releases right?!

Who cares about architect, literally what is deadlock and who will play that ♥♥♥♥, why isn't it a counter strike title? Why do they need all new BS? They had operations, now they just do a new IP no one will care about in a year?

If things go south, for any reason, all this ♥♥♥♥ is gone.
