# VALVE-3RD-TURN

### DISCLAIMER:  This is meant to be a project for the ENTIRE STEAM COMMUNITY.  If a rebase to another repo is needed for a "noncsmpetitive" use, fair.

#FREEVALVE #OpenTheSource #FixSteam #SaveTF2  https://discord.gg/q7RYfmje
https://steamcommunity.com/app/440/discussions/0/4406290986178481007/



# If you are here, you are a Valve End-User who wants to see Valve do better.

# If you are a User who has spent money on Steam, Valve is responsible to provide you a service for the funds they have received.

# If you are an employee for Valve, or your company is Affiliated with Valve, you may have had problems related to Valve, whether on or off premesis.

## The Valve hasn't turned thrice, the well has run dry, now the community needs to be the water source.

The basis for this github is for Users of Steam / Valve Products, who have a problem with a product, conduct of the company, or with the platform Steam, to be able to contribute ideas, or general issues, in a format similar to how Valve works, in order to contribute to solving the issue, rather than sending blank demands.  Part of the history of Valve is working with the modding community.  As it stands, parts of the modding community have been selectively muted, and this is a problem.  Not so disimilar to new hires / contractors being held back from contribution because they are not "Real Valve" yet, as reports have stated.

The problem, as it stands, is not based on any one specific issue, but a number of issues that are tangled together, making rather large messes for users, developers, and in-office staff alike.

This Github is founded in order to create real feedback, with signatures, saying what is or is not liked about the platform, and what the Users think should be worked on.  If you want to help, and make a real change, please, contribute to the repo.

If you want to add a proposal, send one.  If you have ANY issue with steam, valve, the games from Valve specifically, or your user experience compared to other platforms, PLEASE, make a contribution on the issues page.  The community can rank them.

With this feedback loop for Valve, it is hoped that with more End-User perspectives, bad-to-worst case scenarios can be avoided, and the platform be built on user contributions, just like in years past working with mod teams.

Only, this time, the users mod Steam/Valve.
















