You still gotta see the list of people responsible for you being a company, Valve.  We are your Investors.

Aremis Kendall AKA X8X_XZDX
Jani Holopainen AKA UnarmedSoldier
